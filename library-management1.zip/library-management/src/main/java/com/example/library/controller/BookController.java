package com.example.library.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.library.model.Book;
import com.example.library.service.BookService;

@RestController
@RequestMapping("/api/books")
public class BookController {
    private final BookService service;

    public BookController(BookService service) {
        this.service = service;
    }

    // Create a new book
    @PostMapping
    public Book create(@RequestBody Book b) {
        return service.save(b);
    }

    // Get all books
    @GetMapping
    public List<Book> getAll() {
        return service.findAll();
    }

    // Get book by ID
    @GetMapping("/{id}")
    public Book getById(@PathVariable Long id) {
        return service.findById(id);
    }

    // Update book
    @PutMapping("/{id}")
    public Book update(@PathVariable Long id, @RequestBody Book b) {
        Book existing = service.findById(id);
        existing.setTitle(b.getTitle());
        existing.setAuthor(b.getAuthor());
        existing.setIsbn(b.getIsbn());
        existing.setCategory(b.getCategory());
        return service.save(existing);
    }

    // Delete book
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    // Borrow a book
    @PostMapping("/{id}/borrow")
    public Book borrow(@PathVariable Long id) {
        return service.borrowBook(id);
    }

    // Return a book
    @PostMapping("/{id}/return")
    public Book returnBook(@PathVariable Long id) {
        return service.returnBook(id);
    }

    // Archive a book
    @PostMapping("/{id}/archive")
    public Book archive(@PathVariable Long id) {
        return service.archive(id);
    }
}
