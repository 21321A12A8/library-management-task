package com.example.library.service;

import org.springframework.stereotype.Service;
import java.util.List;
import com.example.library.model.Book;
import com.example.library.repository.BookRepository;

@Service
public class BookService {
    private final BookRepository repo;

    public BookService(BookRepository repo) {
        this.repo = repo;
    }

    // Save or update a book
    public Book save(Book b) {
        if (b.getIsbn() != null) {
            Book existing = repo.findByIsbn(b.getIsbn());
            if (existing != null && (b.getId() == null || !existing.getId().equals(b.getId()))) {
                throw new RuntimeException("ISBN already exists");
            }
        }
        return repo.save(b);
    }

    // Get all books
    public List<Book> findAll() {
        return repo.findAll();
    }

    // Get book by ID
    public Book findById(Long id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Book not found: " + id));
    }

    // Delete book
    public void delete(Long id) {
        repo.deleteById(id);
    }

    // Borrow book
    public Book borrowBook(Long id) {
        Book b = findById(id);
        if (!b.isAvailable()) throw new RuntimeException("Book already borrowed");
        b.setAvailable(false);
        return repo.save(b);
    }

    // Return book
    public Book returnBook(Long id) {
        Book b = findById(id);
        b.setAvailable(true);
        return repo.save(b);
    }

    // Archive book
    public Book archive(Long id) {
        Book b = findById(id);
        b.setArchived(true);
        return repo.save(b);
    }
}
